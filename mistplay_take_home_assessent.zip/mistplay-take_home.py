# ### Mistplay Take-home

# #### Import modules
# pip install pandas
# pip install anonymizedf
# pip install fastparquet

import pandas as pd
from fastparquet import write

# Anonymizer Packages
# Anonymize DF
from anonymizedf.anonymizedf import anonymize
# Faker
from faker import Faker

import warnings
warnings.filterwarnings("ignore")


# #### File paths
# path assumes file stored at current location in a "data/" and "secret/" folders
data_file = "data/data.json"
anonymize_key = 'secret/key.csv'


# #### Load JSON data
# file appears to have json data terminated with new line character per expected row
data_df = pd.read_json(data_file, lines=True)


# 1. remove duplicates over the columns id and created_at
data_df.drop_duplicates(subset=['id', 'created_at'], keep = 'first', inplace=True)


# 2. compute the rank of each user's user_score within each age group 
# and output the rank in a new column called "sub_group_rank"
# assuming highest score in sub-group as rank 1
data_df['sub_group_rank'] = data_df.groupby('age_group')['user_score'].rank(ascending=False)


# 3. process the column widget_list by
#  i. flattening the list items i.e. each item in the list is put into its own row
# ii. extracting the values in the JSON elements into their own columns called "widget_name" and "widget_amount"

data_no_explode = data_df.copy()

data_df = data_df.explode('widget_list', ignore_index=True)
data_copy = data_df

columns = data_df.columns
idx = data_df.columns.get_loc('widget_list')
new_columns = ['widget_name', 'widget_amount']

flatten_columns = list(columns[:idx]) + new_columns + list(columns[idx+1:])
rows = []

for _, row in data_df.iterrows():
    # assign NULL values to missing widget_list rows
    try:
        rows.append(
             list(row[columns[0]:columns[idx-1]])
            +[row[columns[idx]:columns[idx]]['widget_list']['name'], 
              row[columns[idx]:columns[idx]]['widget_list']['amount']
             ]
            +list(row[columns[idx+1]:columns[-1]])
        )
    except:
        rows.append(
             list(row[columns[0]:columns[idx-1]])
            +[None, None]
            +list(row[columns[idx+1]:columns[-1]])
        )
        
data_df = pd.DataFrame(rows, columns=flatten_columns)
data_flatten = data_df.copy()


# 4. anonymize the column email and output the anonymized version in a new column email_anon. 
# This column email_anon should have the following properties.
# i. given an anonymized value the original value can be recovered

# Encrypting constants
space_filler = '*'
email_suffix = '@xxx.xxx'
email_dup_sep = '_'

# Create the fake emails
data_email = data_df[['id','email']]
data_email['dup'] = data_email.groupby(['email']).cumcount() + 1
anon = anonymize(data_email)
anon.fake_names('email')

# Create a "Key"
data_email['Fake_email'] = data_email['Fake_email'] \
                          +data_email['id'].str[:3] \
                          +email_dup_sep \
                          +data_email['dup'].map(str)

dfKey = data_email[['email', 'Fake_email']]
dfKey.to_csv(anonymize_key, index=False)

data_email = data_email.assign(email = data_email['Fake_email'])
data_email = data_email.drop(columns='Fake_email')
data_email['email'] = data_email['email'].str.replace(' ',space_filler).apply(lambda x: x+email_suffix)

data_df['email'] = data_email['email']

data_encrypted = data_df.copy()

# Decrypting the emails
# Load in the decoder key
dfKey = pd.read_csv(anonymize_key, index_col=None)

# Return to the original Data
data_email['email'] = data_df['email'].str.replace(email_suffix, '').str.replace(space_filler,' ')
data_df['email'] = data_email['email'].map(dfKey.set_index('Fake_email')['email'])

data_decrypted = data_df.copy()


# 5. create a new table that is an inverted index that gives, 
# for each country in location, which ids are located in that country
location_dict = {}
for _,row in data_df[['location', 'id']].iterrows():
    location_dict[row['location']] = location_dict.get(row['location'], set())
    location_dict[row['location']].add(row['id'])

location_dict = {key:list(value) for (key,value) in location_dict.items()}    
inverted_index = pd.Series(location_dict).to_frame(name='ids')


# 6. write the processed tables/data into separate parquet file(s). 
# Exactly how the files/tables are organized is not as important as having all the data present.

#### Summary of dataframes convert to Parquet ####

# Section 1,2,3: data_flatten
# - Duplicates dropped
# - Sub_group_rank added
# - widget_list exploded and flattened
# - Emails before anonymization

# Section 4: encrypt/decrypt
# - Emails after anonymization (data_encrypted)
# - Emails recovered after anonymization (data_decrypted)

# Section 5: inverted_index
# - new table for inverted on key-country values-ids

write('data/data_flatten.parquet.gzip', data_flatten, compression='GZIP')     #1,2,3 no duplicates,explode & flattened
write('data/data_encrypted.parquet.gzip', data_encrypted, compression='GZIP') #4 encrypt
write('data/data_decrypted.parquet.gzip', data_decrypted, compression='GZIP') #4 decrypt
write('data/inverted_index.parquet.gzip', inverted_index, compression='GZIP') #5


print(pd.read_parquet('data/data_flatten.parquet.gzip').head())
print(pd.read_parquet('data/data_encrypted.parquet.gzip').head())
print(pd.read_parquet('data/data_decrypted.parquet.gzip').head())
print(pd.read_parquet('data/inverted_index.parquet.gzip').head())